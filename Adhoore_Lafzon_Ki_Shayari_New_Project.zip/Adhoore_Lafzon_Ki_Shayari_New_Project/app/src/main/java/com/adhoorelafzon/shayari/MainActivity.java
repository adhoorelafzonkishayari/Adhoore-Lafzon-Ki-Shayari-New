package com.adhoorelafzon.shayari;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private TextView shayari;
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        shayari = findViewById(R.id.txtShayari);
        status = findViewById(R.id.txtStatus);

        Button sad = findViewById(R.id.btnSad);
        Button romantic = findViewById(R.id.btnRomantic);
        Button generate = findViewById(R.id.btnGenerate);

        sad.setOnClickListener(v -> {
            shayari.setText("Kabhi kabhi khamoshi bhi bahut kuch keh jaati hai,\njo baat lafzon se na ho, woh aankhon se reh jaati hai.");
            status.setText("Sad shayari ready");
        });

        romantic.setOnClickListener(v -> {
            shayari.setText("Tera naam likha tha dil ki kitaab mein,\nhar panne par bas tu hi tu mila khwaab mein.");
            status.setText("Romantic shayari ready");
        });

        generate.setOnClickListener(v -> status.setText("Video workflow ready: AI voice + music + branding + social publishing integration."));
    }
}
