# Adhoore Lafzon Ki Shayari

Fresh Android starter project.

- Correct Android XML attribute: `android:textColorHint`
- Branding: `Adhoore Lafzon Ki Shayari`
- Sad/Romantic Shayari starter UI
- GitHub Actions workflow for debug APK

External AI voice and social publishing credentials are intentionally not embedded.
